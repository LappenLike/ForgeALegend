package com.smithy.lappenlike.forgealegend;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;

public class Forge extends BaseActivity {

    public static final String USERID = user.getUid();

    private DocumentReference mDocRef = FirebaseFirestore.getInstance().document("users/USERID/testvalues/aName");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.addContentView(R.layout.forge_activity);


        Button testDataButton = findViewById(R.id.testDataButton);
        testDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, Object> dataToSave = new HashMap<>();
                dataToSave.put("Username", "Name");
                mDocRef.set(dataToSave).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Log.d("Tag", "Gespeichert");
                        } else{
                            Log.d("Tag", "NICHT gespeichert :(");
                        }
                    }
                });
            }
        });

    }
}
